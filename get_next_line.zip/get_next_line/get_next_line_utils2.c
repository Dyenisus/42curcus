/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils2.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yesoytur <yesoytur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/27 16:45:28 by yesoytur          #+#    #+#             */
/*   Updated: 2024/12/28 14:55:51 by yesoytur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <unistd.h>
#include <stddef.h>
#include <stdlib.h>

void	ft_bzero(void *s, size_t n)
{
	size_t			i;
	unsigned char	*a;

	a = (unsigned char *)s;
	i = 0;
	while (i < n)
	{
		a[i] = 0;
		i++;
	}
}

void	*ft_calloc(size_t count, size_t size)
{
	void	*a;

	a = (void *)malloc(count * size);
	if (a == NULL)
		return (NULL);
	ft_bzero(a, count * size);
	return (a);
}

char	*ft_reader(int fd, char *buffer)
{
	int		readed_bytes;
	char	*temp;

	if (!buffer)
		buffer = ft_calloc(1,1);
	temp = (char *)ft_calloc(BUFFER_SIZE + 1, sizeof(char));
	if (!temp)
		return (NULL);
	readed_bytes = 1;
	while (readed_bytes > 0)
	{
		readed_bytes = read(fd, temp, BUFFER_SIZE);
		if (readed_bytes == -1)
		{
			free(buffer);
			free(temp);
			return (NULL);
		}
		buffer = ft_saver(buffer, temp);
		if (ft_strchr(temp, '\n'))
			break ;
	}
	free(temp);
	return (buffer);
}

char	*ft_liner(char *buffer)
{
	int		i;
	char	*line;

	i = 0;
	if (!buffer[i])
		return (NULL);
	while (buffer[i] && buffer[i] != '\n')
		i++;
	line = (char *)ft_calloc(i + 2, sizeof(char));
	if (!line)
		return (NULL);
	i = 0;
	while(buffer[i] && buffer[i] != '\n')
	{
		line[i] = buffer[i];
		i++;
	}
	if (buffer[i])
		line[i++] = '\n';
	return (line);
}

char	*ft_next_line(char	*buffer)
{
	int		i;
	int		j;

	char	*modified_buffer;
	i = 0;
	while(buffer[i] && buffer[i] != '\n')
		i++;
	if (!buffer[i])
	{
		free(buffer);
		return (NULL);
	}
	modified_buffer = (char *)ft_calloc(ft_strlen(buffer) - i + 1, sizeof(char));
	if (!modified_buffer)
		return (NULL);
	i++;
	j = 0;
	while (buffer[i])
		modified_buffer[j++] = buffer[i++];
	free(buffer);
	return (modified_buffer);
}
