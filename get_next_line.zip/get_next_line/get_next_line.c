/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yesoytur <yesoytur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/27 16:44:43 by yesoytur          #+#    #+#             */
/*   Updated: 2024/12/28 15:00:01 by yesoytur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <unistd.h>
#include <stdlib.h>

char	*get_next_line(int fd)
{
	static char *buffer;
	char	*line;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	buffer = ft_reader(fd, buffer);
	if (!buffer)
		return (NULL);
	line = ft_liner(buffer);
	if (!line)
		return (NULL);
	buffer = ft_next_line(buffer);
	return (line);
}

char	*ft_saver(char *temp, char *buffer)
{
	char	*joined;

	joined = ft_strjoin(temp, buffer);
	free(temp);
	return (joined);
}
