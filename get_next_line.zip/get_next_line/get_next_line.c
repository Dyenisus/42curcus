/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yesoytur <yesoytur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/27 16:44:43 by yesoytur          #+#    #+#             */
/*   Updated: 2024/12/28 17:48:56 by yesoytur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char	*ft_saver(char *temp, char *buffer)
{
	char	*joined;

	joined = ft_strjoin(temp, buffer);
	free(temp);
	return (joined);
}

char	*ft_reader(int fd, char *buffer)
{
	int		readed_bytes;
	char	*temp;

	if (!buffer)
		buffer = ft_calloc(1, 1);
	temp = (char *)ft_calloc(BUFFER_SIZE + 1, sizeof(char));
	if (!temp)
		return (NULL);
	readed_bytes = 1;
	while (readed_bytes > 0)
	{
		readed_bytes = read(fd, temp, BUFFER_SIZE);
		if (readed_bytes == -1)
		{
			free(buffer);
			free(temp);
			return (NULL);
		}
		buffer = ft_saver(buffer, temp);
		if (ft_strchr(temp, '\n'))
			break ;
	}
	free(temp);
	return (buffer);
}

char	*ft_liner(char *buffer)
{
	int		i;
	char	*line;

	i = 0;
	if (!buffer[i])
		return (NULL);
	while (buffer[i] && buffer[i] != '\n')
		i++;
	line = (char *)ft_calloc(i + 2, sizeof(char));
	if (!line)
		return (NULL);
	i = 0;
	while (buffer[i] && buffer[i] != '\n')
	{
		line[i] = buffer[i];
		i++;
	}
	if (buffer[i])
		line[i++] = '\n';
	return (line);
}

char	*ft_next_line(char	*buffer)
{
	int		i;
	int		j;
	char	*modified_buffer;

	i = 0;
	while (buffer[i] && buffer[i] != '\n')
		i++;
	if (!buffer[i])
	{
		free(buffer);
		return (NULL);
	}
	modified_buffer = ft_calloc(ft_strlen(buffer) - i + 1, sizeof(char));
	if (!modified_buffer)
		return (NULL);
	i++;
	j = 0;
	while (buffer[i])
		modified_buffer[j++] = buffer[i++];
	free(buffer);
	return (modified_buffer);
}

char	*get_next_line(int fd)
{
	static char	*buffer;
	char		*line;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	buffer = ft_reader(fd, buffer);
	if (!buffer)
		return (NULL);
	line = ft_liner(buffer);
	if (!line)
		return (NULL);
	buffer = ft_next_line(buffer);
	return (line);
}
