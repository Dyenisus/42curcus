/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yesoytur <yesoytur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/20 13:19:50 by yektasoytur       #+#    #+#             */
/*   Updated: 2024/11/30 15:24:45 by yesoytur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>

int	ft_printf(const char *s, ...);
int	ft_putchar(char c);
int	ft_putchar_arg(va_list args);
int	ft_putnbr_arg(va_list args, char *base);
int	ft_putstr_arg(va_list args);
int	ft_putunsigned(va_list args, char *base);
int	ft_putadress(va_list args, char *base);

#endif